import cv2

try:
    from PIL import Image
except ImportError:
    import Image
import pytesseract
import imutils

pytesseract.pytesseract.tesseract_cmd = r'D:\Pantech Solutions\Artifical Intelligence\Day16Code\Tesseract\tesseract.exe'

vs = cv2.VideoCapture(0)
while True:
    _, frame = vs.read()
    frame1 = imutils.resize(frame, width=960, height=540)
    cv2.imshow("picture", frame1)


    # Call the recText function to extract text from the frame
    def recText(frame1):
        text = pytesseract.image_to_string(frame1)
        return text


    info = recText(frame1)
    print(info)

    # Write the result to a file
    file = open("result.txt", "w")
    file.write(info)
    file.close()
    print("Written Successful")

    key = cv2.waitKey(1)
    if key == 27:
        break

vs.release()
cv2.destroyAllWindows()
